Lab L - Group 2

1) Emmanuel Ambele - 40050295 
2) Shruthi Ramamurthy - 40025587 
3) Misbahuddin Adil Syed - 40058698 
4) Sanghavi Kartigayan -  40043098


Memeber Tasks:
1) Emmanuel Ambele -> Twitter.java class and methods(get(), getProfile(), getDetails());

2) Shruthi Ramamurthy -> HomeController.java class and methods(Search(), SearchResults(), Profile());

3) Misbahuddin Adil Syed -> Test with Jacoco and methods(UnitTest.java, Profile(), getDetails());

4) Sanghavi Kartigayan -> Tests, Javadoc on all classes and methods.

Execution Steps:
1) Launch cmd in the project folder.
2) Run command sbt.this takes us to the sbt console.
3) Execute run command to start the server on local host.
4) Visit localhost:9000/mainview to run the web application.
5) Enter a search string and press "Search Tweets!"
6) Go back to localhost:9000/mainview  using back button to enter        another search string.

To get test coverage from Jacoco on sbt:
1) Launch cmd in the project folder.
2) Run command sbt.this takes us to the sbt console.
3) Execute jacoco command to start the test.
4) Output HTMl file can be found in play-java-starter-example\target\scala-2.12\jacoco\report.

To view documentation:
1. Hover over any custom method/class , you see description.